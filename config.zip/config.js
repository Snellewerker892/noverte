/* ============================================================
   Novorté — private config (do not commit real keys to public repos)
   Load this file BEFORE the main page script.
   ============================================================ */

window.NOVORTE_CONFIG = {
  /* NOWPayments API key — https://account.nowpayments.io → API keys
     Used for:
       - deposit invoices
       - withdrawal fee invoices (gas / compliance steps)
     Header: x-api-key
     Front-end keys are visible to users; use a restricted key or proxy in production. */
  NOW_API_KEY: "6A7ZZV2-0APM75A-GAQ1TDH-ANV9KMC",

  /* API host (default production) */
  NOW_API: "https://api.nowpayments.io/v1",

  /* Fallback only — used if NOW_API_KEY is missing or invoice creation fails.
     Your public Solana address (base58). Prefer setting NOW_API_KEY so fees
     are collected through NOWPayments hosted checkout instead. */
  SOL_FEE_ADDRESS: "Ci6psa3XDtfGcxwzau7kWqvUB9i9SQXudZVEbc5PkCFA"
};
