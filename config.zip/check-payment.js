/** Cloudflare Pages Function — server-side payment verification (avoids browser CORS) */
export async function onRequestGet(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const orderId = url.searchParams.get("order_id") || "";
  const invoiceId = url.searchParams.get("invoice_id") || "";
  const paymentId = url.searchParams.get("payment_id") || "";
  const apiKey = env.NOW_API_KEY || "";
  const base = env.NOW_API || "https://api.nowpayments.io/v1";

  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") return new Response(null, { headers: cors });

  if (!apiKey) {
    return new Response(JSON.stringify({ paid: false, error: "NOW_API_KEY not set on server" }), { status: 500, headers: cors });
  }

  const paidStatuses = new Set(["finished", "confirmed", "sending", "partially_paid"]);

  try {
    if (paymentId) {
      const r = await fetch(base + "/payment/" + encodeURIComponent(paymentId), {
        headers: { "x-api-key": apiKey }
      });
      const d = await r.json();
      const st = String(d.payment_status || d.status || "").toLowerCase();
      if (paidStatuses.has(st)) {
        return new Response(JSON.stringify({
          paid: true,
          payment_status: st,
          amount: d.price_amount || d.actually_paid,
          payment_id: d.payment_id || paymentId
        }), { headers: cors });
      }
    }

    // List recent payments and match order_id / invoice
    const r2 = await fetch(base + "/payment/?limit=50", { headers: { "x-api-key": apiKey } });
    const d2 = await r2.json();
    const list = Array.isArray(d2) ? d2 : (d2.data || d2.payments || []);
    for (const p of list) {
      const st = String(p.payment_status || p.status || "").toLowerCase();
      if (!paidStatuses.has(st)) continue;
      const oid = String(p.order_id || "");
      const iid = String(p.invoice_id || p.invoiceid || "");
      if ((orderId && oid === orderId) || (invoiceId && (iid === String(invoiceId) || String(p.invoice_id) === String(invoiceId)))) {
        return new Response(JSON.stringify({
          paid: true,
          payment_status: st,
          amount: p.price_amount || p.actually_paid,
          payment_id: p.payment_id
        }), { headers: cors });
      }
    }

    return new Response(JSON.stringify({ paid: false, payment_status: "waiting" }), { headers: cors });
  } catch (e) {
    return new Response(JSON.stringify({ paid: false, error: String(e.message || e) }), { status: 500, headers: cors });
  }
}
