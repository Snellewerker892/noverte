/** Cloudflare Pages Function — NOWPayments IPN receiver */
export async function onRequestPost(context) {
  const { request, env } = context;
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json"
  };
  try {
    const body = await request.json();
    // Optional: verify HMAC with env.IPN_SECRET (recommended in production)
    // For now acknowledge; client verification uses /api/check-payment
    console.log("IPN", body.payment_id, body.payment_status, body.order_id);
    return new Response(JSON.stringify({ ok: true }), { headers: cors });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false }), { status: 400, headers: cors });
  }
}
